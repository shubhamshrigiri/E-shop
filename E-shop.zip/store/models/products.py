from django.db import models
from .category import Categorie
class Product(models.Model):
    category=models.ForeignKey(Categorie,on_delete=models.CASCADE,default=1)
    name= models.CharField(max_length=50)
    price=models.IntegerField(default=0)
    image=models.ImageField(upload_to='uploads/products/')


    @staticmethod
    def get_all_product():
        return Product.objects.all()

    @staticmethod
    def get_all_product_by_category_id(categoryid):
        if categoryid:
            return  Product.objects.filter(category =categoryid)
        else:
            return Product.get_all_product()

    @staticmethod
    def get_product_by_prodId(ids):
        return Product.objects.filter(id__in=ids)
