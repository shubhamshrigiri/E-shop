from django.shortcuts import  render,redirect
from  django.http import HttpResponse
from django.views import View
from store.models.products import Product
class Cart(View):
    def get(self,request):
        if request.session.get('cart')=={}:
            return  HttpResponse("<h1>No product in your Cart</h1>")
        else:
            ids=(list(request.session.get('cart').keys()))
            products_in_cart=Product.get_product_by_prodId(ids)
            print(products_in_cart)

            return render(request,'cart.html',{'products_in_cart':products_in_cart})