from django.shortcuts import render, redirect
from django.http import  HttpResponse
from store.models.products import Product
from  store.models.category import Categorie
from store.models.customer import Customer
from django.contrib.auth.hashers import make_password,check_password
from django.views import View
class Index(View):
    def post(self,request):

        product=(request.POST.get('product'))
        remove=request.POST.get('remove')
        cart=request.session.get('cart')
        print(cart)
        if cart:
            print("cart running")
            quantity=cart.get(product)
            if quantity:
                if remove:
                    if quantity==1:
                        cart.pop(product)
                    else:
                        cart[product]=quantity-1
                else:

                    cart[product] = quantity + 1
            else:
                cart[product]=1
        else:
            print("else running")
            cart={}
            cart[product]=1
        request.session['cart']=cart
        print("cart",cart)

        print("cart",cart)
        return redirect('index')

    def get(self,request):
        cart=request.session.get('cart')
        if not cart:
            request.session['cart'] = {}
        categorys = Categorie.get_all_categaory()
        categoryid = request.GET.get('category')
        if categoryid:
            products = Product.get_all_product_by_category_id(categoryid)
        else:
            products = Product.get_all_product()
        print("you are : ", request.session.get('email'))
        return render(request, 'index.html', {'products': products, 'categorys': categorys})
'''def index(request):


    categorys=Categorie.get_all_categaory()
    categoryid = request.GET.get('category')
    if categoryid:
        products=Product.get_all_product_by_category_id(categoryid)
    else:
        products=Product.get_all_product()
    print("you are : ",request.session.get('email'))
    return render(request, 'index.html',{'products':products, 'categorys':categorys})'''