from django.shortcuts import  render,redirect
from django.views import View
from store.models.products import Product
from store.models.orders import Order
from store.models.customer import Customer
class Checkout(View):
    def post(self,request):
        address=request.POST.get('address')
        phone=request.POST.get('phone')
        customer=request.session.get('customer_id')
        print(address,phone,customer)
        cart=request.session.get('cart')
        print(cart)
        product_ids=list(cart.keys())
        print("product_ids",product_ids)
        products=Product.get_product_by_prodId(product_ids)
        print("products",products)
        for product in products:
            print("product id",product.id)
            print("customer",customer)
            order=Order(product=product,
                        customer=Customer(id=customer),
                        quantity=cart.get(str(product.id)),
                        price=product.price,
                        address=address,
                        phone=phone)
            order.place_order()
        request.session['cart']={ }
        print(order.product,order.customer,order.price)
        return redirect('cart')
