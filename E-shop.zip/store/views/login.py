from django.shortcuts import render, redirect, HttpResponseRedirect
from django.http import  HttpResponse
from store.models.products import Product
from store.models.category import Categorie
from store.models.customer import Customer
from django.contrib.auth.hashers import make_password,check_password
from django.views import View

class Login(View):
    retutrn_url = None
    def get(self, request):
        Login.return_url = request.GET.get('return_url')
        return render(request, 'login.html')

    def post(self, request):
        username = request.POST.get('username')
        password = request.POST.get('password')
        customer = Customer.get_customer_by_username(username)

        error = None
        if customer:
            password_currect = check_password(password, customer.password)
            if password_currect:
                request.session['customer_id']=customer.id
                request.session['email'] = customer.email
                if Login.return_url:
                    return HttpResponseRedirect(Login.return_url)
                else:
                    Login.retutrn_url=None
                    return redirect('index')
            else:
                error = "Username or Password is invalid"
                return render(request, 'login.html', {'error': error})
        else:
            error = "Username or Password is invalid"
            return render(request, 'login.html', {'error': error})

def logout(request):
    request.session.clear()
    return redirect('login')
def cart(request):
    return render(request,'cart.html')
