from django.shortcuts import render, redirect
from django.http import  HttpResponse
from store.models.products import Product
from  store.models.category import Categorie
from store.models.customer import Customer
from django.contrib.auth.hashers import make_password,check_password
from django.views import View

class Signup(View):
    def get(self,request):
        return render(request, 'signup.html')

    def post(self,request):
        return self.register(request)

    def register(self,request):
        PostData = request.POST
        first_name = PostData.get('firstname')
        last_name = PostData.get('lastname')
        email = PostData.get('email')
        phone = PostData.get('phone')
        password = PostData.get('password')
        confirmpass = PostData.get('confpassword')
        # Data Validation

        customer = Customer(first_name=first_name, last_name=last_name, email=email, phone=phone, password=password)
        value = {'first_name': first_name, 'last_name': last_name, 'email': email, 'phone': phone}
        error_message = self.ValidateCustomer(customer, confirmpass)

        if not error_message:
            customer.password = make_password(password)
            customer.register()
            return redirect('index')

        else:

            data = {
                'error': error_message,
                'values': value
            }

            return render(request, 'signup.html', data)

    def ValidateCustomer(self,customer, confirmpass):
        error_message = None
        if customer.isEmailExist():
            error_message = 'email adderess is already exist !!!'
        elif customer.isPhoneExist():
            error_message = 'Mobile number is already exist !!!'

        elif len(customer.password) < 6:
            error_message = "Password must be 6 char loger !!!"
        elif len(customer.password) > 20:
            error_message = "Password must not be 20 char loger !!!"
        elif customer.password != confirmpass:
            error_message = "password and confirm pass must be match"
        elif len(customer.phone) != 10:
            error_message = "Mobile number must be 10 digit !!!"
        return error_message
