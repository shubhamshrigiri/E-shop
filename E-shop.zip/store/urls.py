from django.urls import path
from .views.home import Index
from .views.signup import Signup
from .views.login import Login, logout
from .views.cart import Cart
from .views.checkout import Checkout
from .views.order import Orderview

urlpatterns=[
    path('',Index.as_view(),name='index'),
    path('signup',Signup.as_view(),name='signup'),
    path('login',Login.as_view(),name='login'),
    path('logout',logout,name='logout'),
    path('cart',Cart.as_view(),name='cart'),
    path('check-out',Checkout.as_view(),name='Check-out'),
    path('order',Orderview.as_view(),name='order')
]


'''
"""
WSGI config for myproject project.

It exposes the WSGI callable as a module-level variable named ``application``.

For more information on this file, see
https://docs.djangoproject.com/en/3.2/howto/deployment/wsgi/
"""

import os

from django.core.wsgi import get_wsgi_application

os.environ.setdefault('DJANGO_SETTINGS_M')
''''''from .views.home import Index
from .views.signup import Signup
from .views.login import Login, logout
from .views.cart import Cart

urlpatterns=[
    path('',Index.as_view(),name='homepage'),
    path('signup',Signup.as_view(),name='homepage'),
    path('login',Login.as_view(),name='login'),
    path('logout',logout,name='logout'),
    path('cart',Cart.as_view(),name='homepage')
]
'''
''''''